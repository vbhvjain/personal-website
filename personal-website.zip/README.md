# Personal website — Vaibhav Jain

Live: **https://vbhvjain.netlify.app**

Static website (HTML, CSS, vanilla JavaScript), no framework and no build step. Hosted on Netlify.

## Features
- Animated hero with a journey video
- Tabbed sections: journey map, experience, Green Aura, skills & education
- Projects page (`projects.html`) with a skill filter and project detail cards
- Light and dark theme, saved per visitor
- Small animated avatar and cat helper
- CV preview and download, QR codes for LinkedIn and WhatsApp

## Run locally
Open `index.html` in a browser, or run:
```bash
python3 -m http.server
```
and visit http://localhost:8000.

## Files
| File | Purpose |
|---|---|
| `index.html` | Home page |
| `projects.html` | Projects gallery |
| `journey.mp4`, `poster.jpg` | Hero video and its poster frame |
| `VaibhavJain_CV.pdf`, `cv.jpg` | CV download and preview |
